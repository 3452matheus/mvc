<?php 
namespace Core; 



class ConfigController {

  private string $url;
  
  private array $urlArral;

  private string $urlMetodo;



    public function __construct () {
        //echo "carregou sua class<br>";
        if (!empty(filter_input(INPUT_GET,'url',FILTER_DEFAULT))){
            $this->url = filter_input(INPUT_GET,'url',FILTER_DEFAULT);
            var_dump($this->url);
            $this->urlArray = explode("/",$this->url);
        }
    }
    public function loadPage(){
        echo "Controllers/pagina";
    }
}